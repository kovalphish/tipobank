"use client"

import { Wallet, PiggyBank, Zap, Target } from "lucide-react"

const accounts = [
  {
    id: 1,
    name: "Текущий счёт",
    balance: "₽124 560,75",
    type: "Основной",
    icon: Wallet,
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 2,
    name: "Накопительный счёт",
    balance: "₽85 320,00",
    type: "Сбережения",
    icon: PiggyBank,
    color: "bg-green-100 text-green-600",
  },
  {
    id: 3,
    name: "Зарплатный счёт",
    balance: "₽45 670,25",
    type: "Зарплата",
    icon: Zap,
    color: "bg-yellow-100 text-yellow-600",
  },
  {
    id: 4,
    name: "Целевой счёт",
    balance: "₽32 100,50",
    type: "Цель",
    icon: Target,
    color: "bg-purple-100 text-purple-600",
  },
]

export function AccountsList() {
  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-6">
      <h3 className="mb-4 sm:mb-6 text-base sm:text-lg font-semibold">Ваши счета</h3>
      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {accounts.map((account) => (
          <div
            key={account.id}
            className="rounded-lg border border-border p-4 hover:shadow-lg transition-shadow cursor-pointer"
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`rounded-lg p-2 ${account.color}`}>
                <account.icon size={20} />
              </div>
              <span className="text-xs font-medium text-muted-foreground">{account.type}</span>
            </div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{account.name}</p>
            <p className="text-lg sm:text-xl font-bold">{account.balance}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

"use client"

import { useState } from "react"
import { ArrowLeft } from "lucide-react"

interface QRPaymentModalProps {
  onClose: () => void
  onPay: () => void
}

export function QRPaymentModal({ onClose, onPay }: QRPaymentModalProps) {
  const [isPaying, setIsPaying] = useState(false)

  const handlePayClick = async () => {
    try {
      setIsPaying(true)
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 800))
      setIsPaying(false)
      onPay()
    } catch (error) {
      console.error("Payment error:", error)
      setIsPaying(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end animate-fade-in">
      <div className="w-full bg-background rounded-t-2xl max-h-[90vh] overflow-y-auto" style={{animation: 'slide-in-up 0.6s ease-out forwards'}}>
        {/* Header */}
        <div className="sticky top-0 flex items-center justify-between px-4 py-3 border-b border-border bg-background">
          <button
            onClick={onClose}
            className="p-1 hover:bg-muted rounded transition"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-sm font-medium text-foreground flex-1 text-center">Оплата</h1>
          <div className="w-8"></div>
        </div>

        <div className="p-3 space-y-3">
          {/* Account card */}
          <div className="bg-gray-600 rounded-xl p-3 text-white animate-fade-in" style={{animationDelay: '0.1s'}}>
            <p className="text-xs font-medium text-gray-300 mb-1">с T-Bank Official</p>
            <p className="text-lg font-bold">1 220 ₽</p>
          </div>

          {/* Merchant info */}
          <div className="bg-pink-500 rounded-xl p-3 text-white flex items-center justify-between animate-fade-in" style={{animationDelay: '0.2s'}}>
            <div>
              <p className="text-sm font-bold">Транспорт</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center flex-shrink-0">
              <div className="text-lg">🚗</div>
            </div>
          </div>

          {/* Description */}
          <div className="animate-fade-in" style={{animationDelay: '0.3s'}}>
            <p className="text-xs text-muted-foreground mb-1">Описание</p>
            <p className="text-xs text-foreground font-medium">оплата заказа</p>
          </div>

          {/* Amount */}
          <div className="text-3xl font-bold text-foreground animate-fade-in" style={{animationDelay: '0.4s'}}>
            35 ₽
          </div>

          {/* Commission info */}
          <p className="text-xs text-muted-foreground animate-fade-in" style={{animationDelay: '0.5s'}}>Комиссия не взимается банком</p>

          {/* Pay button */}
          <button
            onClick={handlePayClick}
            disabled={isPaying}
            className="w-full bg-yellow-400 text-black rounded-xl py-3 font-bold text-base hover:bg-yellow-300 transition disabled:opacity-50 disabled:cursor-not-allowed animate-fade-in-up"
            style={{animationDelay: '0.6s'}}
          >
            {isPaying ? "Обработка..." : "Оплатить 35 ₽"}
          </button>
        </div>
      </div>
    </div>
  )
}

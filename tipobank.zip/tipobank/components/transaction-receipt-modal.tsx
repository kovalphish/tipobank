"use client"

import { X } from "lucide-react"
import { useSiteAccessTime } from "./site-access-context"
import { formatTransactionDate, formatTransactionTime } from "@/lib/date-utils"

interface TransactionReceiptModalProps {
  onClose: () => void
  transaction?: {
    type: string
    merchant: string
    amount: number
  }
}

export function TransactionReceiptModal({ onClose, transaction }: TransactionReceiptModalProps) {
  const accessTime = useSiteAccessTime()

  const defaultTransaction = {
    type: "Транспорт",
    merchant: "Оплата проезда на bilet.nspk.ru",
    amount: 35
  }

  const trans = transaction || defaultTransaction

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col animate-fade-in overflow-y-auto">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 p-2 hover:bg-gray-100 rounded-full transition"
      >
        <X className="w-6 h-6 text-black" />
      </button>

      <div className="flex-1 p-4 max-w-2xl mx-auto w-full space-y-4 pt-4">
        {/* Date and Time */}
        <div className="text-xs text-black animate-fade-in" style={{animationDelay: '0.1s'}}>
          {formatTransactionDate(accessTime)} {formatTransactionTime(accessTime)}
        </div>

        {/* Title and Amount */}
        <div className="flex justify-between items-center pb-3 border-b-2 border-yellow-400 animate-fade-in" style={{animationDelay: '0.2s'}}>
          <h2 className="text-lg font-bold text-black">Итого</h2>
          <span className="text-2xl font-bold text-black">{trans.amount}</span>
        </div>

        {/* Details */}
        <div className="space-y-3 text-sm animate-fade-in" style={{animationDelay: '0.25'}}>
          <div className="flex justify-between">
            <span className="text-black">Покупка</span>
            <span className="text-gray-600">По QR-коду</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">Статус</span>
            <span className="text-black font-medium">Успешно</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">Сумма</span>
            <span className="text-gray-600">{trans.amount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 text-right">{trans.merchant}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">Счет списания</span>
            <span className="text-gray-600">4081781060000****2504</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">Наименование ЮЛ или ИП</span>
            <span className="text-gray-600 text-right">ООО "БЕНТЮК-СМОЛЕНСК"</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">Идентификатор операции</span>
            <span className="text-gray-600">A532212154255B1F000001001116</span>
          </div>
          <div className="flex justify-between">
            <span className="text-black">СБП</span>
            <span className="text-gray-600">30701</span>
          </div>
        </div>

        {/* Stamp */}
        <div className="flex justify-end animate-fade-in" style={{animationDelay: '0.3s'}}>
          <img src="/stamp.png" alt="stamp" className="w-96 h-96 object-contain opacity-80" loading="eager" />
        </div>

        {/* Footer */}
        <div className="text-xs text-gray-600 space-y-1 pt-3 border-t border-yellow-400 animate-fade-in" style={{animationDelay: '0.35s'}}>
          <p>Квитанция № 1-111-184-502-464</p>
          <p>По вопросам зачисления обращайтесь в получателю</p>
          <p>Служба поддержки fb@tbank.ru</p>
        </div>

      </div>
    </div>
  )
}

"use client"

import { useSiteAccess } from "./site-access-context"

interface TransactionDetailModalProps {
  isOpen: boolean
  onClose: () => void
  transaction: {
    name: string
    category: string
    amount: string
    icon: string
    account: string
    date: Date
  }
  onReceiptClick?: () => void
}

export function TransactionDetailModal({ isOpen, onClose, transaction, onReceiptClick }: TransactionDetailModalProps) {
  const { accessTime } = useSiteAccess()

  if (!isOpen) return null

  const formatDate = (date: Date) => {
    const months = [
      "января",
      "февраля",
      "марта",
      "апреля",
      "мая",
      "июня",
      "июля",
      "августа",
      "сентября",
      "октября",
      "ноября",
      "декабря",
    ]
    const day = date.getDate()
    const month = months[date.getMonth()]
    const hours = String(date.getHours()).padStart(2, "0")
    const minutes = String(date.getMinutes()).padStart(2, "0")
    return `${day} ${month} • ${hours}:${minutes}`
  }

  const displayTime = accessTime || new Date()

  const renderIcon = () => {
    if (transaction.icon === "transport") {
      return (
        <div className="w-24 h-24 rounded-full bg-pink-300 flex items-center justify-center animate-scale-in">
          <svg className="w-12 h-12 text-pink-800" fill="currentColor" viewBox="0 0 24 24">
            <path d="M4 16c0 .88.39 1.67 1 2.22V20c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10zm3.5 1c-.83 0-1.5-.67-1.5-1.5S6.67 14 7.5 14s1.5.67 1.5 1.5S8.33 17 7.5 17zm9 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm1.5-6H6V6h12v5z"/>
          </svg>
        </div>
      )
    }
    if (transaction.icon === "beeline") {
      return (
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center animate-scale-in">
          <div className="w-14 h-14 border-4 border-black rounded-full relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-7 h-7 border-t-4 border-black rounded-full"></div>
            </div>
          </div>
        </div>
      )
    }
    if (transaction.icon === "tbank") {
      return (
        <div className="w-24 h-24 rounded-full bg-yellow-400 flex items-center justify-center animate-scale-in">
          <span className="text-4xl font-bold text-black">Т</span>
        </div>
      )
    }
    if (transaction.icon === "avito") {
      return (
        <div className="w-24 h-24 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center animate-scale-in">
          <div className="grid grid-cols-2 gap-1 w-12 h-12">
            <div className="bg-green-500 rounded-sm"></div>
            <div className="bg-cyan-400 rounded-sm"></div>
            <div className="bg-pink-500 rounded-sm"></div>
            <div className="bg-yellow-400 rounded-sm"></div>
          </div>
        </div>
      )
    }
    return (
      <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center animate-scale-in">
        <span className="text-4xl">💰</span>
      </div>
    )
  }

  return (
    <div 
      className="fixed inset-0 bg-black/50 z-50 flex items-end animate-fade-in" 
      onClick={onClose}
    >
      <div
        className="w-full bg-background rounded-t-3xl max-h-[90vh] overflow-y-auto animate-slide-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 pt-6 pb-8">
          <div className="flex items-center justify-between mb-8">
            <span className="text-sm font-medium text-muted-foreground">{formatDate(displayTime)}</span>
            <button
              onClick={onClose}
              className="text-primary text-base font-medium transition duration-300 hover:opacity-70"
            >
              Закрыть
            </button>
          </div>

          <div className="flex justify-center mb-6">
            {renderIcon()}
          </div>

          <div className="text-center mb-2">
            <h2 className="text-xl font-semibold text-foreground">{transaction.name}</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {transaction.category} • MCC 4131
            </p>
          </div>

          <div className="text-center mb-4">
            <p className="text-4xl font-bold text-primary">{transaction.amount}</p>
          </div>

          <div className="flex justify-center mb-6">
            <div className="bg-blue-100 text-blue-600 text-sm font-medium px-5 py-2 rounded-full animate-fade-in-up">
              Округление 5 ₽
            </div>
          </div>

          <div className="flex justify-center mb-8">
            <button className="bg-blue-50 hover:bg-blue-100 rounded-2xl px-8 py-4 flex flex-col items-center gap-2 transition duration-300 hover:scale-105 active:scale-95">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10" strokeWidth="2"/>
                  <path strokeLinecap="round" strokeWidth="2" d="M12 6v12M6 12h12"/>
                </svg>
              </div>
              <span className="text-primary text-sm font-medium">Разделить</span>
            </button>
          </div>

          <div className="bg-card rounded-2xl p-4 animate-fade-in-up">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-base font-semibold text-foreground">Покупка со счета</span>
                <span className="text-lg">💳</span>
              </div>
              {onReceiptClick && (
                <button 
                  onClick={onReceiptClick}
                  className="text-primary text-sm font-medium transition duration-300 hover:opacity-70"
                >
                  Справка
                </button>
              )}
            </div>
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center">
                  <span className="text-lg font-bold text-black">Т</span>
                </div>
                <div>
                  <p className="text-base font-medium text-foreground">T-Bank Official</p>
                  <p className="text-sm text-muted-foreground">1 220 ₽</p>
                </div>
              </div>
              <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

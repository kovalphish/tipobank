"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"

interface SiteAccessContextType {
  accessTime: Date | null
}

const SiteAccessContext = createContext<SiteAccessContextType>({ accessTime: null })

export function SiteAccessProvider({ children }: { children: ReactNode }) {
  const [accessTime, setAccessTime] = useState<Date | null>(null)

  useEffect(() => {
    const storedTime = sessionStorage.getItem("siteAccessTime")
    if (storedTime) {
      setAccessTime(new Date(storedTime))
    } else {
      const now = new Date()
      sessionStorage.setItem("siteAccessTime", now.toISOString())
      setAccessTime(now)
    }
  }, [])

  return (
    <SiteAccessContext.Provider value={{ accessTime }}>
      {children}
    </SiteAccessContext.Provider>
  )
}

export function useSiteAccess() {
  return useContext(SiteAccessContext)
}

export function useSiteAccessTime() {
  const { accessTime } = useContext(SiteAccessContext)
  return accessTime || new Date()
}

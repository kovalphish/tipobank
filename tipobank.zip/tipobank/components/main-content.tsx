"use client"

import { Search, Phone, FileText, Smartphone, QrCode, Heart } from "lucide-react"

export function MainContent() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="p-4 lg:p-6 max-w-7xl mx-auto">
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Поиск"
              className="w-full rounded-lg bg-muted px-4 py-2 pl-10 text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Banners */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          <div className="rounded-xl bg-gradient-to-br from-red-400 to-red-600 p-4 text-white overflow-hidden relative min-h-32">
            <div className="relative z-10">
              <p className="font-bold text-base mb-1">Оценить финансовые навыки</p>
              <p className="text-xs opacity-90">Пройдите тест и узнайте свой уровень</p>
            </div>
          </div>
          <div className="rounded-xl bg-gradient-to-br from-orange-400 to-amber-700 p-4 text-white overflow-hidden relative min-h-32">
            <div className="relative z-10">
              <p className="font-bold text-base mb-1">Продолжаем помогать</p>
              <p className="text-xs opacity-90">Поддерживаем маленькие бизнесы и благотворительность</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          <button className="rounded-lg border border-border bg-card p-3 text-center hover:shadow-md transition-shadow">
            <Phone className="h-5 w-5 mx-auto mb-2 text-primary" />
            <p className="text-xs font-medium">Перевести по телефону</p>
          </button>
          <button className="rounded-lg border border-border bg-card p-3 text-center hover:shadow-md transition-shadow">
            <FileText className="h-5 w-5 mx-auto mb-2 text-primary" />
            <p className="text-xs font-medium">Перевести по реквизитам</p>
          </button>
          <button className="rounded-lg border border-border bg-card p-3 text-center hover:shadow-md transition-shadow">
            <Smartphone className="h-5 w-5 mx-auto mb-2 text-primary" />
            <p className="text-xs font-medium">Оплатить мобильный</p>
          </button>
          <button className="rounded-lg border border-border bg-card p-3 text-center hover:shadow-md transition-shadow">
            <QrCode className="h-5 w-5 mx-auto mb-2 text-primary" />
            <p className="text-xs font-medium">Распознать квитанцию</p>
          </button>
        </div>

        {/* Cashback Section */}
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold">Кэшбэк и бонусы</h3>
            <button className="text-xs text-primary font-medium flex items-center gap-2">
              <Heart size={14} />
              Все предложения
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="rounded-lg bg-gradient-to-br from-green-100 to-green-200 p-4 min-h-28 cursor-pointer hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-bold text-green-900 text-sm mb-0.5">Вкусно — и точка</p>
                  <p className="text-xs text-green-800">Кэшбэк 25%</p>
                </div>
                <div className="h-10 w-10 bg-green-600 rounded-full" />
              </div>
            </div>
            <div className="rounded-lg bg-gradient-to-br from-blue-600 to-blue-900 p-4 min-h-28 text-white cursor-pointer hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-bold text-sm mb-0.5">Добрый в Красное&Белое</p>
                  <p className="text-xs opacity-90">Кэшбэк 10%</p>
                </div>
                <div className="h-10 w-10 bg-red-600 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

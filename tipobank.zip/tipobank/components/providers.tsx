"use client"

import { SiteAccessProvider } from "./site-access-context"

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SiteAccessProvider>
      {children}
    </SiteAccessProvider>
  )
}

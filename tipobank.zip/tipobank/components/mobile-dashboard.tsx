"use client"

import { Eye, EyeOff, Phone, Plus, ArrowRightLeft, QrCode } from "lucide-react"
import { useState } from "react"
import Link from "next/link"
import { QRScanner } from "./qr-scanner"
import { QRPaymentModal } from "./qr-payment-modal"

export function MobileDashboard() {
  const [showBalance, setShowBalance] = useState(true)
  const [showQRScanner, setShowQRScanner] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)

  const handleQRCapture = () => {
    setShowQRScanner(false)
    setShowPaymentModal(true)
  }

  const handlePaymentComplete = () => {
    setShowPaymentModal(false)
  }

  return (
    <div className="flex-1 pb-20 overflow-auto bg-background">
      <div className="p-2 border-b border-border bg-background animate-fade-in">
        <h1 className="text-lg font-bold text-foreground">Главная</h1>
      </div>

      <div className="p-2 space-y-2">
        <div className="mb-3 animate-slide-in-left" style={{animationDelay: '0.05s'}}>
          <input
            type="text"
            placeholder="Поиск"
            className="w-full bg-card rounded-lg px-3 py-2 text-xs placeholder-muted-foreground text-foreground shadow-sm focus:outline-none focus:ring-1 focus:ring-primary border border-border transition"
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* All operations - clickable link to operations page */}
          <Link href="/operations" className="bg-card rounded-xl p-2 shadow-sm hover:shadow-md hover:scale-105 transition cursor-pointer border border-border animate-slide-in-left" style={{animationDelay: '0.1s'}}>
            <h3 className="text-xs font-semibold text-foreground mb-1">Все операции</h3>
            <p className="text-xs font-medium text-muted-foreground mb-1">Тратили в ноябре</p>
            <p className="text-base font-bold text-foreground mb-1">32 586 ₽</p>
            <div className="flex gap-0.5 h-1.5 rounded-full overflow-hidden bg-muted">
              <div className="w-2/3 bg-primary rounded-full animate-pulse-subtle"></div>
              <div className="w-1/6 bg-blue-400 rounded-full animate-pulse-subtle"></div>
              <div className="w-1/6 bg-orange-400 rounded-full animate-pulse-subtle"></div>
            </div>
          </Link>

          {/* Cashback and bonuses */}
          <div className="bg-card rounded-xl p-2 shadow-sm border border-border hover:shadow-md transition animate-slide-in-right" style={{animationDelay: '0.15s'}}>
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="text-xs font-semibold text-foreground">Кэшбэк</h3>
                <p className="text-xs font-semibold text-foreground">и бонусы</p>
              </div>
              <div className="bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-xs font-bold animate-bounce-subtle">
                1
              </div>
            </div>
            <div className="flex gap-1">
              <div className="w-6 h-6 bg-primary rounded-lg animate-scale-in" style={{animationDelay: '0.2s'}}></div>
              <div className="w-6 h-6 bg-teal-600 rounded-lg animate-scale-in" style={{animationDelay: '0.25s'}}></div>
              <div className="w-6 h-6 bg-blue-600 rounded-lg animate-scale-in" style={{animationDelay: '0.3s'}}></div>
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="flex gap-2 justify-between px-1 animate-fade-in-up" style={{animationDelay: '0.35s'}}>
          <div className="flex flex-col items-center gap-1 flex-1">
            <button className="bg-card rounded-lg p-2 hover:bg-muted transition shadow-sm w-full border border-border group">
              <Phone className="w-5 h-5 text-primary mx-auto group-hover:text-white" />
            </button>
            <div className="text-[11px] font-light text-foreground text-center">
              <p>Перевести</p>
              <p className="whitespace-nowrap">по телефону</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-1 flex-1">
            <button className="bg-card rounded-lg p-2 hover:bg-muted transition shadow-sm w-full border border-border group">
              <Plus className="w-5 h-5 text-primary mx-auto group-hover:text-white" />
            </button>
            <div className="text-[11px] font-light text-foreground text-center">
              <p>Пополнить</p>
              <p>Т-банк</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-1 flex-1">
            <button className="bg-card rounded-lg p-2 hover:bg-muted transition shadow-sm w-full border border-border group">
              <ArrowRightLeft className="w-5 h-5 text-primary mx-auto group-hover:text-white" />
            </button>
            <div className="text-[11px] font-light text-foreground text-center">
              <p>Между</p>
              <p>счетами</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-1 flex-1">
            <button 
              onClick={() => setShowQRScanner(true)}
              className="bg-card rounded-lg p-2 hover:bg-muted transition shadow-sm w-full border border-border group"
            >
              <QrCode className="w-5 h-5 text-primary mx-auto group-hover:text-white" />
            </button>
            <div className="text-[11px] font-light text-foreground text-center">
              <p>Сканировать</p>
              <p>QR-код</p>
            </div>
          </div>
        </div>

        {/* Account card */}
        <div className="bg-card rounded-xl p-3 shadow-sm border border-border hover:shadow-md transition animate-fade-in-up" style={{animationDelay: '0.4s'}}>
          <div className="flex items-center gap-3 mb-3">
            <img src="/images/ruble-icon.png" alt="Рубль" className="w-14 h-14 flex-shrink-0" />
            <div className="flex-1">
              <div className="text-base font-bold text-foreground">1 220 ₽</div>
              <p className="text-xs text-muted-foreground">T-Bank Official</p>
            </div>
            <button
              onClick={() => setShowBalance(!showBalance)}
              className="p-1 hover:bg-muted rounded transition flex-shrink-0"
            >
              {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
            </button>
          </div>
          <img src="/images/card-1311-mir.png" alt="Card 1311 МИР" className="w-14 mx-[68px] my-1 h-auto" />
        </div>
      </div>

      {/* QR Scanner */}
      {showQRScanner && (
        <QRScanner 
          onCapture={handleQRCapture}
          onClose={() => setShowQRScanner(false)}
        />
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <QRPaymentModal
          onClose={() => setShowPaymentModal(false)}
          onPay={handlePaymentComplete}
        />
      )}
    </div>
  )
}

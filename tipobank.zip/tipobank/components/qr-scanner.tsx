"use client"

import { useEffect, useRef, useState } from "react"
import { X } from "lucide-react"

interface QRScannerProps {
  onCapture: () => void
  onClose: () => void
}

export function QRScanner({ onCapture, onClose }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isCameraReady, setIsCameraReady] = useState(false)

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" }
        })
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          setIsCameraReady(true)
        }
      } catch (error) {
        console.error("Camera access denied:", error)
        onClose()
      }
    }

    startCamera()

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
        tracks.forEach(track => track.stop())
      }
    }
  }, [onClose])

  const handleCapture = () => {
    onCapture()
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col animate-fade-in">
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 left-4 z-10 bg-black/50 rounded-full p-2 hover:bg-black/70 transition"
      >
        <X className="w-6 h-6 text-white" />
      </button>

      {/* Camera view */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />

      {/* Capture button */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
        <button
          onClick={handleCapture}
          disabled={!isCameraReady}
          className="w-20 h-20 rounded-full bg-white hover:bg-gray-100 transition shadow-lg disabled:opacity-50 disabled:cursor-not-allowed animate-scale-in flex items-center justify-center"
        >
          <div className="w-16 h-16 rounded-full border-4 border-gray-300"></div>
        </button>
      </div>

      {/* Crosshair overlay */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-48 h-48 border-2 border-yellow-400 rounded-lg opacity-50"></div>
      </div>
    </div>
  )
}

"use client"

import { Eye, EyeOff } from "lucide-react"
import { useState } from "react"

export function AccountCard() {
  const [showBalance, setShowBalance] = useState(true)

  return (
    /* Reduced padding and made card more compact */
    <div className="rounded-xl bg-gradient-to-br from-primary via-primary/90 to-primary/80 p-4 sm:p-5 text-primary-foreground">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <p className="mb-1 text-xs sm:text-sm opacity-90">Основной счёт</p>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl sm:text-3xl font-bold">{showBalance ? "₽24 582,50" : "••••••"}</h2>
            <button onClick={() => setShowBalance(!showBalance)} className="rounded-lg p-1 hover:bg-primary/30">
              {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
            </button>
          </div>
        </div>
        <div className="text-right">
          <p className="mb-1 text-xs sm:text-sm opacity-90">Доступно</p>
          <p className="text-lg sm:text-xl font-semibold">₽18 950</p>
        </div>
      </div>

      <div className="mt-3 sm:mt-4 flex items-end justify-between gap-2">
        <div>
          <p className="mb-1 text-xs opacity-75">КАРТА</p>
          <p className="text-xs sm:text-sm font-mono font-semibold">•••• •••• •••• 4829</p>
        </div>
        <div className="text-right">
          <p className="mb-1 text-xs opacity-75">ДЕЙСТВИТЕЛЬНА</p>
          <p className="font-mono text-xs font-semibold">12/26</p>
        </div>
      </div>
    </div>
  )
}

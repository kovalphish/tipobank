# T-Bank Clone - Banking Dashboard

## Project Overview
This is a T-Bank (formerly Tinkoff Bank) banking dashboard clone built with Next.js 16, React 19, TypeScript, and Tailwind CSS. It features a responsive design with separate desktop and mobile layouts showcasing a modern banking interface.

## Tech Stack
- **Framework**: Next.js 16.0.3 (using Turbopack)
- **React**: 19.2.0
- **TypeScript**: ^5
- **Styling**: Tailwind CSS v4.1.9
- **UI Components**: Radix UI primitives
- **Icons**: Lucide React

## Project Structure
```
├── app/                    # Next.js app directory
│   ├── layout.tsx         # Root layout with metadata
│   ├── page.tsx           # Main dashboard page
│   ├── operations/        # Operations page
│   └── globals.css        # Global styles
├── components/            # React components
│   ├── sidebar.tsx        # Desktop sidebar with accounts
│   ├── main-content.tsx   # Desktop main content area
│   ├── mobile-dashboard.tsx  # Mobile dashboard view
│   ├── mobile-navigation.tsx # Mobile bottom navigation
│   └── ui/                # Reusable UI components
└── public/                # Static assets
```

## Key Features
- Responsive design (desktop and mobile layouts)
- Account overview with balance display
- Transaction history
- Payment actions (phone transfer, mobile payment, etc.)
- Cashback and bonus offers
- Dark/light theme support
- Russian language interface

## Development Setup
The project is configured to run on Replit with:
- Port: 5000
- Host: 0.0.0.0 (required for Replit proxy)
- Dev server: Next.js with Turbopack

## Recent Changes
- **2025-11-26**: Initial Replit setup
  - Extracted project from zip file
  - Installed Node.js 20 and dependencies
  - Configured Next.js for Replit environment with allowedDevOrigins
  - Set up workflow on port 5000 with 0.0.0.0 host
  - Added .gitignore for Node.js projects
  - Configured deployment for autoscale with npm build/start

## Environment Configuration
- Next.js configured with `allowedDevOrigins: ["*"]` for Replit proxy support
- TypeScript errors ignored in build for development speed
- Images set to unoptimized mode

## Known Issues
- TypeScript build errors are currently ignored for faster development
- Some components may need additional refinement for production use

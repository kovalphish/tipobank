/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  allowedDevOrigins: [
    '127.0.0.1',
    'localhost',
    '1b6ef04c-fad1-46dc-a9d5-245f9efa0670-00-2c45wv4f23r4f.kirk.replit.dev',
  ],
}

export default nextConfig

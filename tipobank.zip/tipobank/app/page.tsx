"use client"

import { Sidebar } from "@/components/sidebar"
import { MainContent } from "@/components/main-content"
import { MobileNavigation } from "@/components/mobile-navigation"
import { MobileDashboard } from "@/components/mobile-dashboard"

export default function Page() {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop layout */}
      <div className="hidden lg:flex w-full">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-auto">
          <MainContent />
        </div>
      </div>

      {/* Mobile layout */}
      <div className="lg:hidden w-full flex flex-col">
        <MobileDashboard />
      </div>

      <MobileNavigation />
    </div>
  )
}

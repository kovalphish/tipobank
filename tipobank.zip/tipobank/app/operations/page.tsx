"use client"

import { Suspense, useState } from "react"
import Loading from "./loading"
import Link from "next/link"
import { TransactionDetailModal } from "@/components/transaction-detail-modal"
import { TransactionReceiptModal } from "@/components/transaction-receipt-modal"
import { ChevronDown, Search, BarChart3, ArrowLeft } from "lucide-react"

const OperationsContent = () => {
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isReceiptOpen, setIsReceiptOpen] = useState(false)
  const [selectedReceiptTransaction, setSelectedReceiptTransaction] = useState<any>(null)

  const handleTransactionClick = (transaction: any) => {
    setSelectedTransaction(transaction)
    setIsModalOpen(true)
  }

  const handleReceiptClick = (transaction: any) => {
    setSelectedReceiptTransaction(transaction)
    setIsReceiptOpen(true)
  }

  const transactions = {
    today: [
      {
        id: 0,
        name: "Транспорт",
        category: "Местный транспорт",
        amount: "-35 ₽",
        account: "T-Bank Official",
        icon: "transport",
        date: new Date(),
      },
      {
        id: 1,
        name: "Билайн +7 961 364-15-65",
        category: "Мобильная связь",
        amount: "-80 ₽",
        account: "T-Bank Official",
        icon: "beeline",
        date: new Date(),
      },
      {
        id: 2,
        name: "Александр Г.",
        category: "Переводы",
        amount: "-110,71 ₽",
        account: "T-Bank Official",
        icon: "tbank",
        date: new Date(),
      },
      {
        id: 3,
        name: "Avito",
        category: "Маркетплейсы",
        amount: "-157 ₽",
        account: "T-Bank Official",
        icon: "avito",
        date: new Date(),
      },
      {
        id: 4,
        name: "Жахонгир А.",
        category: "Переводы",
        amount: "-40 ₽",
        account: "T-Bank Official",
        icon: "tbank",
        date: new Date(),
      },
    ],
  }

  const renderTransactionIcon = (iconType: string) => {
    switch (iconType) {
      case "beeline":
        return (
          <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
            <div className="w-full h-full bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-black rounded-full relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-3 h-3 border-t-2 border-black rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        )
      case "tbank":
        return (
          <div className="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center flex-shrink-0">
            <span className="text-lg font-bold text-black">Т</span>
          </div>
        )
      case "avito":
        return (
          <div className="w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center flex-shrink-0 overflow-hidden">
            <div className="grid grid-cols-2 gap-0.5 w-6 h-6">
              <div className="bg-green-500 rounded-sm"></div>
              <div className="bg-cyan-400 rounded-sm"></div>
              <div className="bg-pink-500 rounded-sm"></div>
              <div className="bg-yellow-400 rounded-sm"></div>
            </div>
          </div>
        )
      case "transport":
        return (
          <div className="w-10 h-10 rounded-full bg-pink-200 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-pink-600" fill="currentColor" viewBox="0 0 24 24">
              <path d="M4 16c0 .88.39 1.67 1 2.22V20c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10zm3.5 1c-.83 0-1.5-.67-1.5-1.5S6.67 14 7.5 14s1.5.67 1.5 1.5S8.33 17 7.5 17zm9 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm1.5-6H6V6h12v5z"/>
            </svg>
          </div>
        )
      default:
        return (
          <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
            <span className="text-lg">💰</span>
          </div>
        )
    }
  }

  return (
    <>
      <div className="h-dvh flex flex-col bg-background">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-background border-b border-border animate-fade-in">
          <Link href="/" className="p-1 hover:bg-muted rounded transition">
            <ArrowLeft className="w-6 h-6 text-foreground" />
          </Link>
          <h1 className="text-lg font-semibold text-foreground flex-1 text-center">Операции</h1>
          <button className="p-1 hover:bg-muted rounded transition">
            <BarChart3 className="w-6 h-6 text-primary" />
          </button>
        </div>

        {/* Search */}
        <div className="px-4 py-2 bg-background animate-slide-in-left" style={{animationDelay: '0.1s'}}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Поиск"
              className="w-full bg-muted rounded-xl pl-10 pr-4 py-2.5 text-sm placeholder-muted-foreground text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 px-4 py-2 overflow-x-auto bg-background animate-slide-in-left" style={{animationDelay: '0.15s'}}>
          <button className="bg-primary text-white rounded-full px-4 py-1.5 text-sm font-medium flex-shrink-0 flex items-center gap-1">
            Ноябрь
            <ChevronDown className="w-4 h-4" />
          </button>
          <button className="bg-muted text-foreground rounded-full px-4 py-1.5 text-sm font-medium flex-shrink-0 flex items-center gap-1">
            Счета и карты
            <ChevronDown className="w-4 h-4" />
          </button>
          <button className="bg-muted text-foreground rounded-full px-4 py-1.5 text-sm font-medium flex-shrink-0 whitespace-nowrap">
            Без переводов
          </button>
        </div>

        {/* Stats Cards */}
        <div className="flex gap-3 px-4 py-3 bg-background">
          <div className="flex-1 bg-card rounded-2xl p-4 shadow-sm">
            <p className="text-xl font-bold text-foreground mb-0.5">32 586 ₽</p>
            <p className="text-sm text-muted-foreground mb-2">Траты</p>
            <div className="flex gap-0.5 h-1.5 rounded-full overflow-hidden">
              <div className="flex-[5] bg-primary rounded-full"></div>
              <div className="flex-[2] bg-blue-400 rounded-full"></div>
              <div className="flex-[1] bg-teal-400 rounded-full"></div>
              <div className="flex-[1] bg-orange-400 rounded-full"></div>
              <div className="flex-[1] bg-yellow-400 rounded-full"></div>
            </div>
          </div>
          <div className="flex-1 bg-card rounded-2xl p-4 shadow-sm">
            <p className="text-xl font-bold text-foreground mb-0.5">34 339 ₽</p>
            <p className="text-sm text-muted-foreground mb-2">Доходы</p>
            <div className="flex gap-0.5 h-1.5 rounded-full overflow-hidden">
              <div className="flex-[6] bg-blue-500 rounded-full"></div>
              <div className="flex-[4] bg-blue-300 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Transactions List */}
        <div className="flex-1 overflow-y-auto bg-background">
          {/* Today Section */}
          <div className="px-4 py-2">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-base font-bold text-foreground">Сегодня</h3>
              <span className="text-sm text-muted-foreground">-422 ₽</span>
            </div>
            
            <div className="space-y-1">
              {transactions.today.map((transaction) => (
                <button
                  key={transaction.id}
                  onClick={() => handleTransactionClick(transaction)}
                  className="w-full flex items-center gap-3 py-3 hover:bg-muted/50 rounded-xl transition text-left"
                >
                  {renderTransactionIcon(transaction.icon)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{transaction.name}</p>
                    <p className="text-xs text-muted-foreground">{transaction.category}</p>
                  </div>
                  <div className="flex flex-col items-end flex-shrink-0">
                    <p className="text-sm font-medium text-foreground">{transaction.amount}</p>
                    <p className="text-xs text-muted-foreground">{transaction.account}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <TransactionDetailModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        transaction={selectedTransaction || transactions.today[0]}
        onReceiptClick={() => {
          setIsModalOpen(false)
          handleReceiptClick(selectedTransaction || transactions.today[0])
        }}
      />

      {isReceiptOpen && (
        <TransactionReceiptModal
          onClose={() => setIsReceiptOpen(false)}
          transaction={selectedReceiptTransaction}
        />
      )}
    </>
  )
}

export default function Page() {
  return (
    <Suspense fallback={<Loading />}>
      <OperationsContent />
    </Suspense>
  )
}

export default function Loading() {
  return (
    <div className="h-dvh flex flex-col bg-background pb-16">
      {/* Header skeleton */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <div className="w-5 h-5 bg-muted rounded animate-pulse"></div>
        <div className="w-20 h-4 bg-muted rounded animate-pulse"></div>
        <div className="w-5 h-5 bg-muted rounded animate-pulse"></div>
      </div>

      {/* Search skeleton */}
      <div className="px-3 py-2 bg-background border-b border-border">
        <div className="w-full h-8 bg-muted rounded-full animate-pulse"></div>
      </div>

      {/* Filters skeleton */}
      <div className="flex gap-2 px-3 py-2 border-b border-border bg-background">
        <div className="w-20 h-8 bg-primary rounded-full animate-pulse"></div>
        <div className="w-24 h-8 bg-muted rounded-full animate-pulse"></div>
        <div className="w-28 h-8 bg-muted rounded-full animate-pulse"></div>
      </div>

      {/* Stats skeleton */}
      <div className="flex gap-2 px-3 py-2 bg-background border-b border-border">
        <div className="flex-1 bg-card rounded-xl p-2 space-y-1">
          <div className="w-16 h-4 bg-muted rounded animate-pulse"></div>
          <div className="w-12 h-3 bg-muted rounded animate-pulse"></div>
          <div className="w-full h-1 bg-muted rounded-full animate-pulse"></div>
        </div>
        <div className="flex-1 bg-card rounded-xl p-2 space-y-1">
          <div className="w-16 h-4 bg-muted rounded animate-pulse"></div>
          <div className="w-12 h-3 bg-muted rounded animate-pulse"></div>
          <div className="w-full h-1 bg-muted rounded-full animate-pulse"></div>
        </div>
      </div>

      {/* Transactions skeleton */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-3">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex items-center gap-2 bg-card rounded-lg p-2">
            <div className="w-9 h-9 rounded-full bg-muted animate-pulse flex-shrink-0"></div>
            <div className="flex-1 min-w-0 space-y-1">
              <div className="w-24 h-3 bg-muted rounded animate-pulse"></div>
              <div className="w-32 h-2 bg-muted rounded animate-pulse"></div>
            </div>
            <div className="flex flex-col gap-1 flex-shrink-0">
              <div className="w-16 h-3 bg-muted rounded animate-pulse"></div>
              <div className="w-20 h-2 bg-muted rounded animate-pulse"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

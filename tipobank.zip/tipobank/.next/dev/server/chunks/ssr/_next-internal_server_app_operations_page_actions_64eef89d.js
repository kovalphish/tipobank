module.exports = [
"[project]/.next-internal/server/app/operations/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_operations_page_actions_64eef89d.js.map
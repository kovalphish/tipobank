(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f410541f._.js",
  "static/chunks/node_modules_d92d2cfd._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_3a63cca8._.js",
  "static/chunks/node_modules_972aae06._.js"
],
    source: "dynamic"
});

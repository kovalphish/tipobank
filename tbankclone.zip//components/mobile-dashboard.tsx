;<div className="mb-3">
  <input
    type="text"
    placeholder="Поиск"
    className="w-full bg-card rounded-lg px-3 py-2 text-xs placeholder-muted-foreground text-foreground shadow-sm focus:outline-none focus:ring-2 focus:ring-primary transition duration-300"
  />
</div>

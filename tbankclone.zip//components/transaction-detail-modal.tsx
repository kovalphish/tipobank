"use client"

interface TransactionDetailModalProps {
  isOpen: boolean
  onClose: () => void
  transaction: {
    name: string
    category: string
    amount: string
    icon: string
    bgColor: string
    account: string
    date: Date
  }
}

export function TransactionDetailModal({ isOpen, onClose, transaction }: TransactionDetailModalProps) {
  if (!isOpen) return null

  const formatDate = (date: Date) => {
    const months = [
      "января",
      "февраля",
      "марта",
      "апреля",
      "мая",
      "июня",
      "июля",
      "августа",
      "сентября",
      "октября",
      "ноября",
      "декабря",
    ]
    const day = date.getDate()
    const month = months[date.getMonth()]
    const hours = String(date.getHours()).padStart(2, "0")
    const minutes = String(date.getMinutes()).padStart(2, "0")
    return `${day} ${month} • ${hours}:${minutes}`
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end animate-fade-in" onClick={onClose}>
      <div
        className="w-full bg-background rounded-t-2xl p-6 max-h-[90vh] overflow-y-auto animate-slide-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <span className="text-xs font-semibold text-muted-foreground">{formatDate(transaction.date)}</span>
          <button
            onClick={onClose}
            className="text-primary text-sm font-medium transition duration-300 hover:opacity-70"
          >
            Закрыть
          </button>
        </div>

        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div
            className={`w-20 h-20 rounded-full ${transaction.bgColor} flex items-center justify-center text-4xl animate-scale-in`}
          >
            {transaction.icon}
          </div>
        </div>

        {/* Transaction Details */}
        <div className="text-center mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-1">{transaction.name}</h2>
          <p className="text-xs text-muted-foreground">{transaction.category}</p>
        </div>

        {/* Amount */}
        <div className="text-center mb-4">
          <p className="text-3xl font-bold text-foreground">{transaction.amount}</p>
        </div>

        {/* Rounding Badge */}
        <div className="flex justify-center mb-6">
          <div className="bg-blue-200 text-blue-700 text-xs font-medium px-4 py-1.5 rounded-full animate-fade-in-up">
            Округление 5 ₽
          </div>
        </div>

        {/* Share Button */}
        <button className="w-full bg-blue-100 text-primary rounded-lg py-3 mb-6 text-sm font-medium flex items-center justify-center gap-2 transition duration-300 hover:scale-105 active:scale-95">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"
            />
          </svg>
          Разделить
        </button>

        {/* Account Info */}
        <div className="bg-card rounded-lg p-4 animate-fade-in-up">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold text-foreground">Покупка со счета</span>
            <button className="text-primary text-xs font-medium transition duration-300 hover:opacity-70">
              Справка
            </button>
          </div>
          <div className="flex items-center gap-2 mt-3">
            <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">
              Р
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">T-Bank Official</p>
              <p className="text-xs text-muted-foreground">1 220 ₽</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

// Wrap page with Suspense for dynamic features
import { Suspense, useState } from "react"
import Loading from "./loading"
import Link from "next/link"
import { TransactionDetailModal } from "@/components/transaction-detail-modal"

const OperationsContent = () => {
  const [selectedTransaction, setSelectedTransaction] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleTransactionClick = (transaction) => {
    setSelectedTransaction(transaction)
    setIsModalOpen(true)
  }

  const transportTransaction = {
    name: "Транспорт",
    category: "Местный транспорт • МСС 4131",
    amount: "-35 ₽",
    icon: "🚌",
    bgColor: "bg-pink-200",
    account: "T-Bank Official",
    date: new Date(),
  }

  const BackIcon = () => (
    <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
    </svg>
  )

  const StatsIcon = () => (
    <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
      />
    </svg>
  )

  const SearchIcon = () => (
    <svg className="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
      />
    </svg>
  )

  return (
    <>
      <div className="h-dvh flex flex-col bg-background pb-16">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-border">
          <Link href="/" className="p-1 hover:bg-muted rounded transition">
            <BackIcon />
          </Link>
          <h1 className="text-base font-semibold text-foreground flex-1 text-center">Операции</h1>
          <StatsIcon />
        </div>

        {/* Search */}
        <div className="px-3 py-2 bg-background border-b border-border">
          <div className="relative">
            <SearchIcon />
            <input
              type="text"
              placeholder="Поиск"
              className="w-full bg-muted rounded-full pl-8 pr-3 py-1.5 text-xs placeholder-muted-foreground text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 px-3 py-2 border-b border-border overflow-x-auto bg-background">
          <button className="bg-primary text-white rounded-full px-3 py-1 text-xs font-medium flex-shrink-0 flex items-center gap-1">
            Ноябрь
            <span>▼</span>
          </button>
          <button className="bg-muted text-foreground rounded-full px-3 py-1 text-xs font-medium flex-shrink-0">
            Счета и карты
          </button>
          <button className="bg-muted text-foreground rounded-full px-3 py-1 text-xs font-medium flex-shrink-0 whitespace-nowrap">
            Без переводов
          </button>
        </div>

        {/* Stats */}
        <div className="flex gap-2 px-3 py-2 bg-background border-b border-border">
          <div className="flex-1 bg-card rounded-xl p-2">
            <p className="text-xs font-bold text-foreground">32 586 ₽</p>
            <p className="text-xs text-muted-foreground mb-1">Траты</p>
            <div className="flex gap-0.5 h-1 rounded-full overflow-hidden bg-muted">
              <div className="w-2/3 bg-primary"></div>
              <div className="w-1/6 bg-blue-400"></div>
              <div className="w-1/6 bg-orange-400"></div>
            </div>
          </div>
          <div className="flex-1 bg-card rounded-xl p-2">
            <p className="text-xs font-bold text-foreground">34 339 ₽</p>
            <p className="text-xs text-muted-foreground mb-1">Доходы</p>
            <div className="flex gap-0.5 h-1 rounded-full overflow-hidden bg-muted">
              <div className="w-1/2 bg-teal-500"></div>
              <div className="w-1/2 bg-cyan-400"></div>
            </div>
          </div>
        </div>

        {/* Transactions */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-3">
          {/* Today */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground px-2 py-1">Сегодня</h3>
            <div className="space-y-2">
              <button
                onClick={() => handleTransactionClick(transportTransaction)}
                className="w-full flex items-center gap-2 bg-card rounded-lg p-2 hover:bg-muted transition text-left"
              >
                <div className="w-9 h-9 rounded-full bg-pink-200 flex items-center justify-center flex-shrink-0">
                  <span className="text-lg">🚌</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Транспорт</p>
                  <p className="text-xs text-muted-foreground">Местный транспорт</p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0">
                  <p className="text-xs font-bold text-foreground">-35 ₽</p>
                  <p className="text-xs text-muted-foreground">T-Bank Official</p>
                </div>
              </button>
            </div>
          </div>

          {/* Previous Days */}
          <div>
            <h3 className="text-xs font-semibold text-muted-foreground px-2 py-1">Предыдущие дни</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 bg-card rounded-lg p-2">
                <div className="w-9 h-9 rounded-full bg-yellow-200 flex items-center justify-center flex-shrink-0">
                  <span className="text-lg">🐝</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Билайн +7 961 364-15-65</p>
                  <p className="text-xs text-muted-foreground">Мобильная связь</p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0">
                  <p className="text-xs font-bold text-foreground">-80 ₽</p>
                  <p className="text-xs text-muted-foreground">T-Bank Official</p>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-card rounded-lg p-2">
                <div className="w-9 h-9 rounded-full bg-yellow-200 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold">Т</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Александр Г.</p>
                  <p className="text-xs text-muted-foreground">Переводы</p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0">
                  <p className="text-xs font-bold text-foreground">-110,71 ₽</p>
                  <p className="text-xs text-muted-foreground">T-Bank Official</p>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-card rounded-lg p-2">
                <div className="w-9 h-9 rounded-full bg-green-200 flex items-center justify-center flex-shrink-0">
                  <span className="text-lg">🎨</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground">Avito</p>
                  <p className="text-xs text-muted-foreground">Маркетплейсы</p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0">
                  <p className="text-xs font-bold text-foreground">-157 ₽</p>
                  <p className="text-xs text-muted-foreground">T-Bank Official</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <TransactionDetailModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        transaction={selectedTransaction || transportTransaction}
      />
    </>
  )
}

export default function Page() {
  return (
    <Suspense fallback={<Loading />}>
      <OperationsContent />
    </Suspense>
  )
}

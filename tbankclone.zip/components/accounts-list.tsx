"use client"

const accounts = [
  {
    id: 1,
    name: "Текущий счёт",
    balance: "₽124 560,75",
    type: "Основной",
  },
  {
    id: 2,
    name: "Накопительный счёт",
    balance: "₽85 320,00",
    type: "Сбережения",
  },
  {
    id: 3,
    name: "Зарплатный счёт",
    balance: "₽45 670,25",
    type: "Зарплата",
  },
  {
    id: 4,
    name: "Целевой счёт",
    balance: "₽32 100,50",
    type: "Цель",
  },
]

export function AccountsList() {
  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-6">
      <h3 className="mb-4 sm:mb-6 text-base sm:text-lg font-semibold">Ваши счета</h3>
      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {accounts.map((account) => (
          <div
            key={account.id}
            className="rounded-lg border border-border p-4 hover:shadow-lg transition-shadow cursor-pointer"
          >
            <div className="mb-3"></div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{account.name}</p>
            <p className="text-lg sm:text-xl font-bold">{account.balance}</p>
            <span className="text-xs font-medium text-muted-foreground">{account.type}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

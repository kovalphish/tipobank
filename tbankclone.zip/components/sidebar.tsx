"use client"

import { Eye, ChevronDown } from "lucide-react"
import { useState } from "react"

const sidebarAccounts = [
  { id: 1, amount: "1 220", name: "T-Bank Official", type: "main" },
  { id: 2, amount: "0 из 10 000", name: "Афон", type: "credit" },
  { id: 3, amount: "1 080,04", name: "Инвестиции", change: "+47 Р", changePercent: "+4,6%", type: "invest" },
  { id: 4, amount: "546,13", name: "102M", change: "+0,36 Р", type: "account" },
  { id: 5, amount: "Мобильная связь", name: "T-MoБайл", type: "service" },
]

export function Sidebar() {
  const [showBalance, setShowBalance] = useState(true)
  const [hideProducts, setHideProducts] = useState(false)

  return (
    <aside className="hidden w-72 border-r border-border bg-background p-6 lg:flex flex-col fixed left-0 top-0 bottom-0 lg:relative overflow-y-auto">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-foreground">Добрый день</h2>
      </div>

      {/* Accounts List */}
      <div className="space-y-3 flex-1">
        {sidebarAccounts.map((account) => (
          <div
            key={account.id}
            className="rounded-lg border border-border bg-card p-4 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary flex-shrink-0">
                <span className="text-sm font-bold text-primary-foreground">Р</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-bold text-foreground">{account.amount}</p>
                <p className="text-xs text-muted-foreground">{account.name}</p>
                {account.change && (
                  <p className="text-xs text-green-600 font-medium">
                    {account.change} {account.changePercent}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Hidden Products */}
      <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4 py-2">
        <Eye size={16} />
        <span>Скрытые продукты</span>
        <ChevronDown size={16} className="ml-auto" />
      </button>

      {/* New Account Button */}
      <button className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-bold hover:opacity-90 transition-opacity">
        Новый счет или продукт
      </button>
    </aside>
  )
}

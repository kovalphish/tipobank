export function StatsCards() {
  const stats = [
    {
      label: "Income",
      value: "$12,450",
      change: "+12.5%",
    },
    {
      label: "Expenses",
      value: "$8,920",
      change: "+5.2%",
    },
    {
      label: "Transfers",
      value: "$2,100",
      change: "-2.1%",
    },
    {
      label: "Savings",
      value: "$15,630",
      change: "+8.3%",
    },
  ]

  return (
    <div className="grid gap-3 sm:gap-4 grid-cols-2 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div key={stat.label} className="rounded-xl border border-border bg-card p-4 sm:p-6">
          <div className="mb-3 sm:mb-4">
            <h3 className="text-xs sm:text-sm font-medium text-muted-foreground">{stat.label}</h3>
          </div>
          <p className="mb-2 text-xl sm:text-2xl font-bold">{stat.value}</p>
          <p className="text-xs text-muted-foreground">{stat.change} this month</p>
        </div>
      ))}
    </div>
  )
}

"use client"

import { Home, CreditCard, MapPin, MessageCircle, MoreHorizontal } from "lucide-react"
import { useState } from "react"

export function MobileNavigation() {
  const [active, setActive] = useState("home")

  const items = [
    { id: "home", icon: Home, label: "Главная" },
    { id: "payments", icon: CreditCard, label: "Платежи" },
    { id: "city", icon: MapPin, label: "Город" },
    { id: "chat", icon: MessageCircle, label: "Чат" },
    { id: "more", icon: MoreHorizontal, label: "Ещё" },
  ]

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 border-t border-border bg-card">
      <div className="flex items-center justify-around">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setActive(item.id)}
            className={`relative flex flex-col items-center gap-1 px-4 py-3 text-xs font-medium transition-colors my-0 ${
              active === item.id ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <div className="relative">
              <item.icon size={18} strokeWidth={2.5} />
            </div>
            <span>{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  )
}

const transactions = [
  {
    id: 1,
    name: "Netflix Subscription",
    category: "Entertainment",
    amount: "-$15.99",
    date: "Today",
  },
  {
    id: 2,
    name: "Salary Deposit",
    category: "Income",
    amount: "+$4,500",
    date: "Yesterday",
  },
  {
    id: 3,
    name: "Electric Bill",
    category: "Utilities",
    amount: "-$125.50",
    date: "2 days ago",
  },
  {
    id: 4,
    name: "Transfer to Savings",
    category: "Transfer",
    amount: "-$1,000",
    date: "3 days ago",
  },
  {
    id: 5,
    name: "Freelance Payment",
    category: "Income",
    amount: "+$850",
    date: "5 days ago",
  },
]

export function TransactionsList() {
  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-6 lg:col-span-1">
      <h3 className="mb-4 sm:mb-6 text-base sm:text-lg font-semibold">Recent Transactions</h3>
      <div className="space-y-3 sm:space-y-4">
        {transactions.map((transaction) => (
          <div
            key={transaction.id}
            className="flex items-center justify-between rounded-lg border border-border p-3 sm:p-4 transition-colors hover:bg-muted"
          >
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <div className={`rounded-lg bg-muted p-2 sm:p-3 flex-shrink-0`}></div>
              <div className="min-w-0">
                <p className="font-medium text-sm sm:text-base truncate">{transaction.name}</p>
                <p className="text-xs text-muted-foreground">{transaction.date}</p>
              </div>
            </div>
            <p className="font-semibold text-sm sm:text-base flex-shrink-0">{transaction.amount}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
